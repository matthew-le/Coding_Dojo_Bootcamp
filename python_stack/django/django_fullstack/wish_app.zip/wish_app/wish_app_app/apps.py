from django.apps import AppConfig


class WishAppAppConfig(AppConfig):
    name = 'wish_app_app'
