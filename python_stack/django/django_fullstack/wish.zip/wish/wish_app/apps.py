from django.apps import AppConfig


class WishAppConfig(AppConfig):
    name = 'wish_app'
