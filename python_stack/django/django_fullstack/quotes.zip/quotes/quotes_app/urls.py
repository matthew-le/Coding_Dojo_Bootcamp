from django.urls import path
from . import views

urlpatterns = [
    path('', views.log_and_reg),
    path('register', views.register),
    path('login', views.login),
    path('quotes', views.index),
    path('logout', views.logout),
    path('quotes/process', views.process_quote),
    path('user/<int:user_id>', views.view_quotes),
    path('user/<int:user_id>/edit', views.edit_user),
    path('user/<int:user_id>/update', views.update_user),
    path('quotes/<int:quote_id>/like', views.like),
    path('quotes/<int:quote_id>/unlike', views.unlike),
    path('quotes/<int:quote_id>/delete', views.delete)
]