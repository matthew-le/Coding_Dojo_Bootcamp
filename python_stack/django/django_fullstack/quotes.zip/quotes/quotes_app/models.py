from django.db import models
import re 

# Create your models here.
class QuoteManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['author']) < 3:
            errors['author'] = 'Author name must be more than 3 characters'
        if len(postData['content']) < 10:
            errors['content'] = 'Quote must contain more than 10 characters'
        return errors

class UserManager(models.Manager):
    def user_validator(self, postData):
        errors = {}
        users = User.objects.filter(email=postData['email'])
        if users: 
            errors['existing_user'] = 'Email already tied to existing account'
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):           
            errors['email'] = ("Invalid email address!")
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name should be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name should be at least 2 characters"
        if postData['password'] != postData['confirm_password']:
            errors['password'] = 'Password does not match confirmation password'
        if len(postData['password']) < 8:
            errors['password'] = 'Password should be at least 8 characters'
        return errors
    def login_validator(self, postData):
        errors = {}
        users = User.objects.filter(email=postData['email'])
        if len(postData['email']) < 1:
            errors['email'] = 'Email cannot be blank'
        if len(postData['password']) < 8:
            errors['password'] = 'Password should be at least 8 characters'
        return errors
    def edit_validator(self, postData, user_id):
        errors = {}
        users = User.objects.filter(email=postData['email'])
        if users: 
            my_user = User.objects.get(id=user_id)
            if my_user.email != users[0].email:
                errors['email'] = 'email is already in user'
            else: 
                EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
                if not EMAIL_REGEX.match(postData['email']):           
                    errors['email'] = ("Invalid email address!")
                if len(postData['first_name']) < 1:
                    errors['first_name'] = "First name cannot be blank"
                if len(postData['last_name']) < 1:
                    errors['last_name'] = "Last name cannot be blank"
        else: 
            EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
            if not EMAIL_REGEX.match(postData['email']):           
                errors['email'] = ("Invalid email address!")
            if len(postData['first_name']) < 1:
                errors['first_name'] = "First name cannot be blank"
            if len(postData['last_name']) < 1:
                errors['last_name'] = "Last name cannot be blank"
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()


    def __repr__(self):
        return f"<Show Information: {self.first_name} ({self.id})>"

class Quote(models.Model):
    content = models.TextField()
    author = models.CharField(max_length=255)
    posted_by = models.ForeignKey(User, related_name='quotes', on_delete=models.CASCADE)
    users_who_liked = models.ManyToManyField(User, related_name='quotes_user_liked')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = QuoteManager()