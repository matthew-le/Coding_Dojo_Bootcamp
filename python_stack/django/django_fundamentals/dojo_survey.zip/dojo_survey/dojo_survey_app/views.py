from django.shortcuts import render, redirect
# Create your views here.

def index(request):
    return render(request, 'form.html')

def result(request):
    if request.method == 'POST':
        context = {
            "full_name": request.POST["full_name"],
            "dojo_location": request.POST["dojo_location"],
            "fav_language": request.POST["fav_language"],
            "comment_area": request.POST["comment_area"]
        }
    return render(request, 'result_form.html', context)

