from django.apps import AppConfig


class RwgAppConfig(AppConfig):
    name = 'rwg_app'
